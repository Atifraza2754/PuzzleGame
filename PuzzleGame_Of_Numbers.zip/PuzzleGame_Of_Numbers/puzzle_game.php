<?php
echo "<center>";
$bh1 = $_GET['bh1'];
$bh2 = $_GET['bh2'];
$bh3 = $_GET['bh3'];
$bh4 = $_GET['bh4'];
$bh5 = $_GET['bh5'];
$bh6 = $_GET['bh6'];
$bh7 = $_GET['bh7'];
$bh8 = $_GET['bh8'];
$bh9 = $_GET['bh9'];

$date=date("d-m-Y");


if (isset($_GET['b1'])) {

    if ($bh2 == " ") {
        $bh2 = $bh1;
        $bh1 = " ";
    } //end bh1

    else if ($bh4 == " ") {
        $bh4 = $bh1;
        $bh1 = " ";
    } //end bh1

} //end b1


else if (isset($_GET['b2'])) {

    if ($bh1 == " ") {
        $bh1 = $bh2;
        $bh2 = " ";
    } //end bh2

    else if ($bh3 == " ") {
        $bh3 = $bh2;
        $bh2 = " ";
    } //end bh3

    else if ($bh5 == " ") {
        $bh5 = $bh2;
        $bh2 = " ";
    } //end bh3

} //end b2

//start b3
else if (isset($_GET['b3'])) {
    if ($bh2 == " ") {
        $bh2 = $bh3;
        $bh3 = " ";
    } elseif ($bh6 == " ") {
        $bh6 = $bh3;
        $bh3 = " ";
    }
}
//end btn3

//start b4
else if (isset($_GET['b4'])) {
    if ($bh1 == " ") {
        $bh1 = $bh4;
        $bh4 = " ";
    } elseif ($bh5 == " ") {
        $bh5 = $bh4;
        $bh4 = " ";
    } elseif ($bh7 == " ") {
        $bh7 = $bh4;
        $bh4 = " ";
    }
}
//end btn4

//start b5
else if (isset($_GET['b5'])) {
    if ($bh2 == " ") {
        $bh2 = $bh5;
        $bh5 = " ";
    } elseif ($bh4 == " ") {
        $bh4 = $bh5;
        $bh5 = " ";
    } elseif ($bh6 == " ") {
        $bh6 = $bh5;
        $bh5 = " ";
    } elseif ($bh8 == " ") {
        $bh8 = $bh5;
        $bh5 = " ";
    }
}
//end btn5

//start btn6

else if (isset($_GET['b6'])) {
    if ($bh3 == " ") {
        $bh3 = $bh6;
        $bh6 = " ";
    } elseif ($bh5 == " ") {
        $bh5 = $bh6;
        $bh6 = " ";
    } elseif ($bh9 == " ") {
        $bh9 = $bh6;
        $bh6 = " ";
    }
}
//end btn6

//start btn7

else if (isset($_GET['b7'])) {
    if ($bh4 == " ") {
        $bh4 = $bh7;
        $bh7 = " ";
    } elseif ($bh8 == " ") {
        $bh8 = $bh7;
        $bh7 = " ";
    }
}
//end btn7

//start btn8
else if (isset($_GET['b8'])) {
    if ($bh5 == " ") {
        $bh5 = $bh8;
        $bh8 = " ";
    } elseif ($bh7 == " ") {
        $bh7 = $bh8;
        $bh8 = " ";
    } elseif ($bh9 == " ") {
        $bh9 = $bh8;
        $bh8 = " ";
    }
}
//end btn8

//start btn9
else if (isset($_GET['b9'])) {
    if ($bh6 == " ") {
        $bh6 = $bh9;
        $bh9 = " ";
    } elseif ($bh8 == " ") {
        $bh8 = $bh9;
        $bh9 = " ";
    }
}

echo "
<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Puzzle</title>
    <link href='../Bootstrap/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        h1.bg-brown {
            background-color: brown;
        }

        footer.bg-dark {
            background-color: skyblue !important;
        }

        footer .text-white {
            color: red !important;
        }
    </style>
</head>

<body class='bg-dark'>
    <nav class='navbar navbar-expand-lg navbar-light bg-info'>
        <div class='container-fluid'>
            <a class='navbar-brand' href='#'>
                <img src='logo.jpeg' alt='Logo' width='50' height='50' class='d-inline-block align-text-top rounded-circle'>
            </a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
                <span class='navbar-toggler-icon'></span>
            </button>
            <div class='collapse navbar-collapse' id='navbarNav'>
                <ul class='navbar-nav mx-auto'>
                    <li class='nav-item'>
                        <a class='nav-link text-danger' href='Home.html'>Home</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link text-danger' href='about.html'>About us</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link text-danger' href='course.html'>Courses</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link text-danger' href='contact.html'>Contact us</a>
                    </li>
                </ul>
            </div>
            <a class='navbar-brand' href='#'>
                <img src='navttcc.png' alt='Navttcc' width='50' height='50' class='d-inline-block align-text-top rounded-circle'>
            </a>
        </div>
    </nav>
    <h2 class='text-white'>Date : $date</h2>
    <div class='container my-5'>
        <div class='text-center mb-4'>
        <center>
            <h1 class='bg-brown text-white p-3 rounded' style='max-width: 500px;'>Puzzle Game</h1>
        </center>
        </div>

        
        <div class='card mx-auto p-4' style='max-width: 500px; background-color: lightgreen; border-radius: 40px;'>
            <form action='puzzle_game.php' method='GET'>
                <div class='d-flex justify-content-center'>
                    <input type='hidden' name='bh1' value='$bh1'>
                    <input type='submit' name='b1' Value='$bh1' class='btn btn-secondary m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh2' value='$bh2'>
                    <input type='submit' name='b2' value='$bh2'  class='btn btn-secondary m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh3' value='$bh3'>
                    <input type='submit' name='b3' value='$bh3' class='btn btn-secondary m-2' style='width: 80px; height: 80px;'>

                </div>
                <div class='d-flex justify-content-center'>
                    <input type='hidden' name='bh4' value='$bh4'>
                    <input type='submit' name='b4' value='$bh4' class='btn btn-info m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh5' value='$bh5'>
                    <input type='submit' name='b5' value='$bh5' class='btn btn-info m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh6' value='$bh6'>
                    <input type='submit' name='b6' value='$bh6' class='btn btn-info m-2' style='width: 80px; height: 80px;'>

                </div>
                <div class='d-flex justify-content-center'>
                    <input type='hidden' name='bh7' value='$bh7'>
                    <input type='submit' name='b7' value='$bh7' class='btn btn-danger m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh8' value='$bh8'>
                    <input type='submit' name='b8' value='$bh8' class='btn btn-danger m-2' style='width: 80px; height: 80px;'>

                    <input type='hidden' name='bh9' value='$bh9'>
                    <input type='submit' name='b9' value='$bh9' class='btn btn-danger m-2' style='width: 80px; height: 80px;'>
                    
                </div>
            </form>
        </div>
    </div>

    <footer class='bg-dark text-white text-center text-lg-start mt-5'>
        <div class='container p-4'>
            <div class='row'>
                <div class='col-lg-4 col-md-6 mb-4 mb-md-0'>
                    <h5 class='text-uppercase'>Course: Full Stack Development</h5>
                </div>
                <div class='col-lg-4 col-md-6 mb-4 mb-md-0'>
                    <h5 class='text-uppercase'>Trainer: Sir Hadi Bux</h5>
                </div>
                <div class='col-lg-4 col-md-6 mb-4 mb-md-0'>
                    <h5 class='text-uppercase'>Student Name : Aatif Raza</h5>
                </div>
            </div>
        </div>
    </footer>

    <script src='../Bootstrap/js/bootstrap.bundle.js'></script>
</body>

</html>";

if ($bh1 == 1 && $bh2 == 2 && $bh3 == 3 && $bh4 == 4 && $bh5 == 5 && $bh6 == 6 && $bh7 == 7 && $bh8 == 8) {
    echo "<h2 id='result'>Congratulations ! You Won</h2>";
    echo "<a href='puzzle.html'><input type='submit'  class='restart' value='Restart Game'></a>";
    echo "</div>";
} //condition 



?>
